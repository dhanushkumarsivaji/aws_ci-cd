import {createContext} from 'react';

const contactContext = createContext()

export default contactContext;