

// Don't be like me and commit this file!
// These keys have been disabled, but remain here for reference purposes.
module.exports = {
  mongoURI: 'mongodb://Dhanush1995:S*dk1995@cluster0-shard-00-00-iork0.mongodb.net:27017,cluster0-shard-00-01-iork0.mongodb.net:27017,cluster0-shard-00-02-iork0.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority',
  jwtSecret: "secret",
  redisUrl: 'redis://127.0.0.1:6379'
};
